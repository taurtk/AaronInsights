document.addEventListener('DOMContentLoaded', () => {
    const ideaForm = document.getElementById('idea-form');
    const promptInput = document.getElementById('prompt');
    const loadingDiv = document.getElementById('loading');
    const ideasContainer = document.getElementById('ideas-container');
    const exampleButtons = document.querySelectorAll('.example-button');

    ideaForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const prompt = promptInput.value;
        if (prompt) {
            await generateIdeas(prompt);
        }
    });

    exampleButtons.forEach(button => {
        button.addEventListener('click', async () => {
            const prompt = button.textContent.trim().substring(2);
            promptInput.value = prompt;
            await generateIdeas(prompt);
        });
    });

    async function generateIdeas(prompt) {
        loadingDiv.style.display = 'block';
        ideasContainer.innerHTML = '';

        const formData = new FormData();
        formData.append('prompt', prompt);

        const response = await fetch('/generate_ideas', {
            method: 'POST',
            body: new URLSearchParams(formData)
        });

        const result = await response.json();
        loadingDiv.style.display = 'none';

        if (result.success) {
            displayIdeas(result.clusters);
        } else {
            ideasContainer.innerHTML = `<p style="color: red; text-align: center;">${result.error}</p>`;
        }
    }

    function displayIdeas(clusters) {
        for (const [cluster, ideas] of Object.entries(clusters)) {
            let clusterHtml = `<div class="ideas-header"><h2>🎯 ${cluster.charAt(0).toUpperCase() + cluster.slice(1)}</h2></div>`;
            
            ideas.forEach((ideaData, i) => {
                clusterHtml += `
                    <div class="idea-card">
                        <h3>💡 Idea ${i + 1}</h3>
                        <p>${ideaData.idea}</p>
                        
                        <div class="metric-grid">
                            <div class="metric-card">⭐ Novelty<br>${ideaData.novelty || 8}/10</div>
                            <div class="metric-card">🎯 Uniqueness<br>${ideaData.uniqueness || 7}/10</div>
                            <div class="metric-card">💰 Business Value<br>${ideaData.business_value || 9}/10</div>
                        </div>

                        ${ideaData.justification ? `<p><strong>💭 Analysis:</strong> ${ideaData.justification}</p>` : ''}

                        ${ideaData.market_analysis ? `
                            <div style="background: #f0f9ff; padding: 1rem; border-radius: 10px; margin: 1rem 0;">
                                <h4 style="color: #1e40af; margin-bottom: 0.5rem;">📊 Market Analysis</h4>
                                <p><strong>Market Size:</strong> ${ideaData.market_analysis.tam || 'Analyzing...'}</p>
                                <p><strong>Growth Rate:</strong> ${ideaData.market_analysis.cagr || 'Calculating...'}</p>
                            </div>
                        ` : ''}

                        ${ideaData.competitive_landscape ? `
                            <div class="competitor-list">
                                <h4 style="color: #dc2626; margin-bottom: 0.5rem;">🏆 Competitive Landscape</h4>
                                ${ideaData.competitive_landscape.direct_competitors ? `
                                    <p><strong>Direct Competitors:</strong></p>
                                    <ul>
                                        ${ideaData.competitive_landscape.direct_competitors.map(c => `<li><strong>${c.name || 'Unknown'}:</strong> ${c.description || 'N/A'}</li>`).join('')}
                                    </ul>
                                ` : ''}
                                ${ideaData.competitive_landscape.differentiator ? `<p><strong>🎯 Key Differentiator:</strong> ${ideaData.competitive_landscape.differentiator}</p>` : ''}
                            </div>
                        ` : ''}

                        ${ideaData.monetization ? `
                            <div style="background: #f0fdf4; padding: 1rem; border-radius: 10px; margin: 1rem 0;">
                                <h4 style="color: #166534; margin-bottom: 0.5rem;">💰 Monetization Strategy</h4>
                                <p><strong>Primary Model:</strong> ${ideaData.monetization.primary_model || 'TBD'}</p>
                                <p><strong>Pricing Strategy:</strong> ${ideaData.monetization.pricing_strategy || 'TBD'}</p>
                            </div>
                        ` : ''}

                        ${ideaData.roadmaps ? `
                            <div class="metric-grid">
                                ${ideaData.roadmaps.hackathon_mvp ? `
                                    <div class="roadmap-section">
                                        <h4 style="color: #166534; margin-bottom: 0.5rem;">🚀 Hackathon MVP (${ideaData.roadmaps.hackathon_mvp.timeline || '2-4 weeks'})</h4>
                                        <ul>${ideaData.roadmaps.hackathon_mvp.milestones.map(m => `<li>${m}</li>`).join('')}</ul>
                                    </div>
                                ` : ''}
                                ${ideaData.roadmaps.investor_pitch ? `
                                    <div class="roadmap-section">
                                        <h4 style="color: #166534; margin-bottom: 0.5rem;">💼 Investor Pitch (${ideaData.roadmaps.investor_pitch.timeline || '3-6 months'})</h4>
                                        <ul>${ideaData.roadmaps.investor_pitch.milestones.map(m => `<li>${m}</li>`).join('')}</ul>
                                    </div>
                                ` : ''}
                            </div>
                        ` : ''}
                    </div>
                `;
            });
            ideasContainer.innerHTML += clusterHtml;
        }
    }
});